﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication7.Migrations
{
    public partial class data : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "PostTypeId",
                table: "Taxanomies",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Posts",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    PostTypeId = table.Column<int>(nullable: false),
                    Tittle = table.Column<string>(nullable: false),
                    CreationDate = table.Column<int>(nullable: false),
                    Detail = table.Column<string>(nullable: true),
                    Summary = table.Column<string>(nullable: false),
                    TermListId = table.Column<int>(nullable: false),
                    Image = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Posts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Posts_Taxanomies_TermListId",
                        column: x => x.TermListId,
                        principalTable: "Taxanomies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "PostTypes",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Article = table.Column<string>(nullable: true),
                    Tittle = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PostTypes", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Taxanomies_PostTypeId",
                table: "Taxanomies",
                column: "PostTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Posts_TermListId",
                table: "Posts",
                column: "TermListId");

            migrationBuilder.AddForeignKey(
                name: "FK_Taxanomies_PostTypes_PostTypeId",
                table: "Taxanomies",
                column: "PostTypeId",
                principalTable: "PostTypes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Taxanomies_PostTypes_PostTypeId",
                table: "Taxanomies");

            migrationBuilder.DropTable(
                name: "Posts");

            migrationBuilder.DropTable(
                name: "PostTypes");

            migrationBuilder.DropIndex(
                name: "IX_Taxanomies_PostTypeId",
                table: "Taxanomies");

            migrationBuilder.DropColumn(
                name: "PostTypeId",
                table: "Taxanomies");
        }
    }
}
