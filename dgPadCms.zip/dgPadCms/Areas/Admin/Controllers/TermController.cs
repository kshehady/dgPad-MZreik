﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication7.Infrastrucure;
using WebApplication7.Models;

namespace WebApplication7.Areas.Admin.Controllers
{
    //[Authorize(Roles = "admin")]
    [Area("Admin")]
    public class TermController : Controller
    {
        private readonly dgPadCmsContext context;
        public TermController(dgPadCmsContext context)
        {
            this.context = context;
        }
        public async Task<IActionResult> Index(int p = 1)
        {
            int pageSize = 6;
            var terms = context.Terms.OrderByDescending(x => x.Id)
                                            .Include(x => x.Taxanomy)
                                            .Skip((p - 1) * pageSize)
                                            .Take(pageSize);

            ViewBag.PageNumber = p;
            ViewBag.PageRange = pageSize;
            ViewBag.TotalPages = (int)Math.Ceiling((decimal)context.Terms.Count() / pageSize);

            return View(await terms.ToListAsync());
        }
        public async Task<IActionResult> Details(int id)
        {
           Term term = await context.Terms.Include(x => x.Taxanomy).FirstOrDefaultAsync(x => x.Id == id);
            if (term == null)
            {
                return NotFound();
            }

            return View(term);
        }
        public IActionResult Create()
        {
            ViewBag.TaxanomyId = new SelectList(context.Taxanomies.OrderBy(x => x.Sorting), "Id", "Name");

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Term term)
        {
            ViewBag.TaxanomyId = new SelectList(context.Taxanomies.OrderBy(x => x.Sorting), "Id", "Name");

            if (ModelState.IsValid)
            {
                term.Name = term.Name.ToLower().Replace(" ", "-");

                var slug = await context.Terms.FirstOrDefaultAsync(x => x.Name== term.Name);
                if (slug != null)
                {
                    ModelState.AddModelError("", "The term already exists.");
                    return View(term);
                }

              
                context.Add(term);
                await context.SaveChangesAsync();

                TempData["Success"] = "The term has been added!";

                return RedirectToAction("Index");
            }

            return View(term);
        }
        public async Task<IActionResult> Edit(int id)
        {
           Term term = await context.Terms.FindAsync(id);
            if (term == null)
            {
                return NotFound();
            }

            ViewBag.TaxanomyId = new SelectList(context.Taxanomies.OrderBy(x => x.Sorting), "Id", "Name", term.TaxanomyId);

            return View(term);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id,Term term)
        {
            ViewBag.TaxanomyId = new SelectList(context.Taxanomies.OrderBy(x => x.Sorting), "Id", "Name", term.TaxanomyId);

            if (ModelState.IsValid)
            {
                term.Name = term.Name.ToLower().Replace(" ", "-");

                var name = await context.Terms.Where(x => x.Id != id).FirstOrDefaultAsync(x => x.Name == term.Name);
                if (name != null)
                {
                    ModelState.AddModelError("", "The term already exists.");
                    return View(term);
                }

               

                context.Update(term);
                await context.SaveChangesAsync();

                TempData["Success"] = "The term has been edited!";

                return RedirectToAction("Index");
            }

            return View(term);
        }
        public async Task<IActionResult> Delete(int id)
        {
           Term term = await context.Terms.FindAsync(id);

            if (term == null)
            {
                TempData["Error"] = "The term does not exist!";
            }
            else
            {
              

                context.Terms.Remove(term);
                await context.SaveChangesAsync();

                TempData["Success"] = "The term has been deleted!";
            }

            return RedirectToAction("Index");
        }
    }
}