﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication7.Infrastrucure;
using WebApplication7.Models;
//using Microsoft.AspNetCore.Hosting;

namespace WebApplication7.Controllers
{
    [Area("Admin")]
    public class PostController : Controller
    {
        private readonly dgPadCmsContext context;

       

        public PostController(dgPadCmsContext context)
        {
            this.context = context;
          
        }
        public IActionResult Index()
        {


            return View(context.Posts.ToList());
        }
        public async Task<IActionResult> Details(int id)
        {
            var post = await context.Posts.FindAsync(id);
            ViewBag.Term = await context.PostTypes.Where(x => x.Id == id).Include(x => x.Taxanomy).ToArrayAsync();
            ViewBag.PostType.FindAsync(post.PostTypeId);
            return View(post);
        }
        public IActionResult Create()
        {
            ViewBag.TermList = new SelectList(context.Taxanomies.OrderBy(x => x.Sorting), "Id", "Name");
            
              return  View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Post post)
        {
            if (ModelState.IsValid)

            {
                post.Tittle = post.Tittle.ToLower().Replace(" ", "-");

                var title = await context.Posts.FirstOrDefaultAsync(x => x.Tittle == post.Tittle);
                if (title != null)
                {
                    ModelState.AddModelError("", "The Post already exists.");
                    return View(post);
                }


                string imageName = "noimage.png";
                if (post.ImageUpload != null)
                {
                    string uploadsDir = Path.Combine( "media/products");
                    imageName = Guid.NewGuid().ToString() + "_" + post.ImageUpload.FileName;
                    string filePath = Path.Combine(uploadsDir, imageName);
                    FileStream fs = new FileStream(filePath, FileMode.Create);
                    await post.ImageUpload.CopyToAsync(fs);
                    fs.Close();
                }

                post.Image = imageName;

                context.Add(post);
                await context.SaveChangesAsync();

                TempData["Success"] = "The Post has been added!";

                return RedirectToAction("Index");
            }

            return View(post);
        }
        public async Task<IActionResult> Edit(string tittle)
        {
            Post post = await context.Posts.FindAsync(tittle);
            if (post == null)
            {
                return NotFound();
            }

            ViewBag.TermList = new SelectList(context.Taxanomies.OrderBy(x => x.Sorting), "Id", "Name", post.TermListId);

            return View(post);
        }
        public async Task<IActionResult> Edit(Post post)
        {
            if (ModelState.IsValid)
            {
                var tittle = await context.Posts.Where(x => x.Tittle != post.Tittle).FirstOrDefaultAsync(x => x.Tittle == post.Tittle);
                if (tittle != null)
                {
                    ModelState.AddModelError("", "The Post already exists.");
                    return View(post);
                }
                if (post.ImageUpload != null)
                {
                    string uploadsDir = Path.Combine("media/post");

                    if (!string.Equals(post.Image, "noimage.png"))
                    {
                        string oldImagePath = Path.Combine(uploadsDir, post.Image);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }

                    string imageName = Guid.NewGuid().ToString() + "_" + post.ImageUpload.FileName;
                    string filePath = Path.Combine(uploadsDir, imageName);
                    FileStream fs = new FileStream(filePath, FileMode.Create);
                    await post.ImageUpload.CopyToAsync(fs);
                    fs.Close();
                    post.Image = imageName;
                }

                context.Update(post);
                await context.SaveChangesAsync();

                TempData["Success"] = "The post has been edited!";

                return RedirectToAction("Edit", new { tittle = post.Tittle });
            }

            return View(post);
        }
        public async Task<IActionResult> Delete(string tittle)
        {
            Post post = await context.Posts.FindAsync(tittle);

            if (post == null)
            {
                TempData["Error"] = "The post does not exist!";
            }
            else
            {
                if (!string.Equals(post.Image, "noimage.png"))
                {
                    string uploadsDir = Path.Combine( "media/products");
                    string oldImagePath = Path.Combine(uploadsDir, post.Image);
                    if (System.IO.File.Exists(oldImagePath))
                    {
                        System.IO.File.Delete(oldImagePath);
                    }
                }
                context.Posts.Remove(post);
                await context.SaveChangesAsync();

                TempData["Success"] = "The post has been deleted!";
            }

            return RedirectToAction("Index");
        }
    }
}