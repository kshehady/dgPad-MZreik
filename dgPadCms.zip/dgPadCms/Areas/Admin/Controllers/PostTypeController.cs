﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication7.Infrastrucure;
using WebApplication7.Models;

namespace WebApplication7.Areas.Admin.Controllers
{
    public class PostTypeController : Controller
    {
            private readonly dgPadCmsContext context;

            public PostTypeController(dgPadCmsContext context)
            {
                this.context = context;
            }

        public IActionResult Index()
        {


            return View(context.PostTypes.ToList());
        }
        public async Task<IActionResult> Details(string article)
        {
           PostType post = await context.PostTypes.FirstOrDefaultAsync(x=> x.Article == article);
            if (post == null)
            {
                return NotFound();
            }

            return View(post);
        }
        public IActionResult Create() => View();
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(PostType post)
        {
            if (ModelState.IsValid)
            {
               post.Tittle = post.Tittle.ToLower().Replace(" ", "-");
               
                var title = await context.PostTypes.FirstOrDefaultAsync(x => x.Tittle ==post.Tittle);
                if (title != null)
                {
                    ModelState.AddModelError("", "The Post already exists.");
                    return View(post);
                }

                context.Add(post);
                await context.SaveChangesAsync();

                TempData["Success"] = "The Post has been added!";

                return RedirectToAction("Index");
            }

            return View(post);
        }
        public async Task<IActionResult> Edit( string tittle)
        {
            PostType post = await context.PostTypes.FindAsync(tittle);
            if (post == null)
            {
                return NotFound();
            }

            return View(post);
        }
        public async Task<IActionResult> Edit(PostType post)
        {
            if (ModelState.IsValid)
            {
                var tittle = await context.PostTypes.Where(x => x.  Tittle != post.Tittle).FirstOrDefaultAsync(x => x.Tittle == post.Tittle);
                if (tittle != null)
                {
                    ModelState.AddModelError("", "The Post already exists.");
                    return View(post);
                }

                context.Update(post);
                await context.SaveChangesAsync();

                TempData["Success"] = "The post has been edited!";

                return RedirectToAction("Edit", new {tittle = post.Tittle });
            }

            return View(post);
        }
        public async Task<IActionResult> Delete(string tittle)
        {
            PostType post = await context. PostTypes.FindAsync(tittle);

            if (post == null)
            {
                TempData["Error"] = "The post does not exist!";
            }
            else
            {
                context.PostTypes.Remove(post);
                await context.SaveChangesAsync();

                TempData["Success"] = "The post has been deleted!";
            }

            return RedirectToAction("Index");
        }
    }

}