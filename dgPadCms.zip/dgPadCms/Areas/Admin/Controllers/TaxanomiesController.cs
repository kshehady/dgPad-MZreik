﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication7.Infrastrucure;
using WebApplication7.Models;

namespace WebApplication7.Areas.Admin.Controllers
{

   // [Authorize(Roles = "admin")]
    [Area("Admin")]
    public class TaxanomiesController : Controller
    {
        private readonly dgPadCmsContext context;
        public TaxanomiesController(dgPadCmsContext context)
        {
            this.context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await context.Taxanomies.OrderBy(x => x.Sorting).ToListAsync());
        }
        public IActionResult Create() => View();

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Taxanomy taxanomy)
        {
            if (ModelState.IsValid)
            {
                taxanomy.Name = taxanomy.Name.ToLower().Replace(" ", "-");
                taxanomy.Sorting = 100;

                var name = await context.Taxanomies.FirstOrDefaultAsync(x => x.Name == taxanomy.Name);
                if (name != null)
                {
                    ModelState.AddModelError("", "The taxanomy already exists.");
                    return View(taxanomy);
                }

                context.Add(taxanomy);
                await context.SaveChangesAsync();

                TempData["Success"] = "The taxanomy has been added!";

                return RedirectToAction("Index");
            }

            return View(taxanomy);
        }
        public async Task<IActionResult> Edit(int id)
        {
            Taxanomy taxanomy = await context.Taxanomies.FindAsync(id);
            if (taxanomy == null)
            {
                return NotFound();
            }

            return View(taxanomy);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Taxanomy taxanomy)
        {
            if (ModelState.IsValid)
            {
                taxanomy.Name = taxanomy.Name.ToLower().Replace(" ", "-");

                var name = await context.Taxanomies.Where(x => x.Id != id).FirstOrDefaultAsync(x => x.Name == taxanomy.Name);
                if (name!= null)
                {
                    ModelState.AddModelError("", "The taxanomy already exists.");
                    return View(taxanomy);
                }

                context.Update(taxanomy);
                await context.SaveChangesAsync();

                TempData["Success"] = "The taxanomy has been edited!";

                return RedirectToAction("Edit", new { id });
            }

            return View(taxanomy);
        }
        public async Task<IActionResult> Delete(int id)
        {
            Taxanomy taxanomy = await context.Taxanomies.FindAsync(id);

            if (taxanomy == null)
            {
                TempData["Error"] = "The taxanomy does not exist!";
            }
            else
            {
                context.Taxanomies.Remove(taxanomy);
                await context.SaveChangesAsync();

                TempData["Success"] = "The taxanomy has been deleted!";
            }

            return RedirectToAction("Index");
        }
        [HttpPost]
        public async Task<IActionResult> Reorder(int[] id)
        {
            int count = 1;

            foreach (var TaxanomyId in id)
            {
                Taxanomy taxanomy = await context.Taxanomies.FindAsync(TaxanomyId);
                taxanomy.Sorting = count;
                context.Update(taxanomy);
                await context.SaveChangesAsync();
                count++;
            }

            return Ok();
        }
    }
}
