﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebApplication7.Infrastrucure;
using WebApplication7.Models;
//using Microsoft.AspNetCore.Hosting;

namespace WebApplication7.Controllers
{
    public class PostPublicController : Controller
    {
        private readonly dgPadCmsContext context;
              

        public PostPublicController(dgPadCmsContext context)
        {
            this.context = context;
          
        }
        public IActionResult Index()
        {
            return View(context.Posts.ToList());
        }
        public async Task<IActionResult> Details(int Id)
        {
            Post post = await context.Posts.FirstOrDefaultAsync(x => x.PostTypeId == Id);
            if (post == null)
            {
                return NotFound();
            }

            return View(post);
        }
      
    }
}