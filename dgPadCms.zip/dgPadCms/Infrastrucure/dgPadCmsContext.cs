﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication7.Models;

namespace WebApplication7.Infrastrucure
{
    public class dgPadCmsContext:DbContext
    {
            
        public dgPadCmsContext(DbContextOptions<dgPadCmsContext> options)
            : base(options)
        {
        }

        public DbSet<Page> Pages { get; set; }
        public DbSet<Taxanomy> Taxanomies { get; set; }
        public DbSet<Term>Terms { get; set; }
        public DbSet<PostType> PostTypes { get; set; }
        public DbSet<Post> Posts { get; set; }
    }
}
