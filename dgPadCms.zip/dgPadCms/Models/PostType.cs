﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication7.Models
{
    public class PostType
    {
        public int Id { get; set; }
        public string Article { get; set; }
        public string Tittle { get; set; }
        public List<Taxanomy> Taxanomy { get; set; }

    }
}
