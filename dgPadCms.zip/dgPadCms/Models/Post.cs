﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WebApplication7.Infrastrucure;

namespace WebApplication7.Models
{
    public class Post
    {
        public  int Id { get; set; }
        public int PostTypeId { get; set; }
        [Required, MinLength(2, ErrorMessage = "Minimum length is 2")]
        public string Tittle { get; set; }
        public int CreationDate { get; set; }
        public string Detail { get; set; }
        [Required, MinLength(4, ErrorMessage = "Minimum length is 4")]
        public string Summary { get; set; }
        [Display(Name = "Category")]
        [Range(1, int.MaxValue, ErrorMessage = "You must choose a category")]
        public int TermListId { get; set; }     
        public string Image { get; set; }
      
        [ForeignKey("TermListId")]
        public virtual Taxanomy Taxanomy { get; set; }
        [NotMapped]
        [FileExtension]
        public IFormFile ImageUpload { get; set; }

        
    }
}
